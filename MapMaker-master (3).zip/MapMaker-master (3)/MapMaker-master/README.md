# MapMaker

Sophia-edit2 notes:
Changed Map text box to a Domain Up Down since I feel like maybe it could work better, but if you disagree then I understand and it's an easy change. So when you create a new map, it should add in a Map 2 option. Not entirely sure how to go about clearing the previous info though.

Added another possible way to save files. Unsure of which would work better since I can't test it without the array.

sam-11/11 edits :
Took info Prof. Kalb put in and began expanding it to cover all four players' icons, locations, etc.

Sophia-milestone3 edits:
Thought about Prof. Kalb's advice on some of the buttons. Fixed the save button; it now writes to a textfile all of the information. Clear and Create New work better now as well.

Sophia edit 4 notes:
Clear works properly. Added in functionality for "upload background" button. It just shows the file location for whatever image you choose. Still need to figure out how to make a save file dialog work when creating a new map...the way I tried made it crash.
 
Sophia edit 5 notes:
Added in a save file dialog that comes up when the users tries to clear or create new. Prompts them to go back and save before making changes.
